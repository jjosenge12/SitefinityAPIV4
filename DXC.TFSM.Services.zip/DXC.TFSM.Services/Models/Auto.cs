﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DXC.TFSM.Services.Models
{
    public class Auto
    {
        public int id_auto { get; set; }
        public string des_auto { get; set; }
    }
}